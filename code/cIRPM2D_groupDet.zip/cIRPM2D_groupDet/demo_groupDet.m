% ---------------------------------------------------------------------------------------------- % 
%                   Code for detecting groups of people (PRAI and Expert System paper) 
%                   efficient version for 2D data on ground floor
%                   L. Bazzani and M. Cristani, April 18, 2011
% ---------------------------------------------------------------------------------------------- % 
%
% Thanks to A. Fossati and D. Tosato to have provided head tracking and
% head pose estimation, respectively 


close all;
clear all;
clc;


%% IRPM Patameters
theta_deg   = 120; % degree of the field of view
L           = 600; % max length of the field of view (cm)
distTH      = 200; % social interaction max distance (cm)
verbose 	= 0;   % if you want to visualize details (instantaneous IRPM)
SHIFT       = 10;  % size of the time window of the cIRPM
THRESH      = 6;   % threshold on cIRPM


%% Paths
addpath(genpath('./MAT/'));
addpath(genpath('./3rd_part_libs'))
addpath(genpath('./utils'))
direhead 	=   './MAT/head_orientations/';



%% Load Calibration (homography)
load('homography.mat');
[mytform, registered]   =   registration(pts,pts_planar_ref);
load('groundTruth_groups.mat')
GT = GTconoscenza;

%% Data Loading
listahead   =   dir(strcat(direhead,'*.mat')); % load pre-computed head orientation
num_subj    =   size(listahead,1);
index       =   0;
for k=1:num_subj
    load(strcat(direhead,listahead(k).name));
    if size(result,2)~=5 continue
    else
        index                   =   index +1;
        ofeatures(index,:,:)    =   reshape(result(:,[1:5])',[1,5,size(result,1)]); 
                                     % Original features [feetx,feety,orientation];
                                     % MARCO: specify the coord system!!!
    end
end


%% Set plot
scrinfo  = get( 0, 'ScreenSize' );
win1info = [scrinfo(1),scrinfo(2),floor(scrinfo(3)*5/6),scrinfo(4)];
figure; set(gcf,'name','Sequence Analysis','position',win1info);


%% Start online computing
num_img     =   length(GT);
group = cell(1,num_img); % instantaneous groups
IRPM  = cell(1,num_img); % instantaneous IRPM
cgroup = cell(1,num_img);  % cumulative groups
cIRPM  = cell(1,num_img); % cumulative IRPM
precision = zeros(1,num_img);
recall    = zeros(1,num_img);
FN        = zeros(1,num_img);
FP        = zeros(1,num_img);
TP        = zeros(1,num_img);

for t=1:num_img % images have been processed (tracking, head orientation) one each 10 frames
    
    fprintf('frame %i|%i\n',t,num_img);
    features            =   [];
    labels              =   [];   
    
    %% Project coordinate into ground floor feature = [x,y,theta,label]
    gfeatures           =   ofeatures(:,:,t); 
    rindex              =   0;
    for n=1:index %for each subject
        
        if gfeatures(n,1)~=-1 % analyze the features of the subject, if the subject n was visible at time k;
            rindex      =   rindex +1;

            % projection
            t_points                =   gfeatures(n,3:4)';
            [X,Y]                   =   tformfwd(T,t_points(2,:)',t_points(1,:)');
            t_hom                   =   [X';Y'];
            t_points(t_points~=0)   =   1;
            t_points(t_points==0)   =   NaN;
            pfeatures               =   [t_hom.*t_points]'; 

            % Orientation labels mapping (quantization with 4 quanti)
            switch gfeatures(n,5)
                case 1;pfeatures(3) =   pi/2;
                case 2;pfeatures(3) =   3/2*pi;
                case 3;pfeatures(3) =   0;
                case 4;pfeatures(3) =   pi;
            end
            features(rindex,:)  =   pfeatures;

            labels(rindex)  =   n; % identifying the subject
        end
    end
    features                =   [features,labels']; 
        

    
    %% FoA-based Method   <===  This is the main block you could be interested to
    % Compute the Isntantaneous IRPM
    [group{t},IRPM{t}]   = inst_IRPM(features,distTH,theta_deg,L,verbose); 
      
    % fit the max size of the IRPM
    if size(IRPM{t},1)<num_subj 
       TMPgMtt = zeros(num_subj,num_subj);
       TMPgMtt(1:size(IRPM{t},1),1:size(IRPM{t},2)) = IRPM{t};
       IRPM{t} = TMPgMtt;
    end
    
    % Compute the Cumulative IRPM
    [cgroup{t},cIRPM{t}]   = cum_IRPM(IRPM,num_subj,t,SHIFT,THRESH);
    
    
    %% plot
    subplot(131),imagesc(registered); title('Registered Image with tracked people'); hold on; axis image;
    for n=1:size(features,1)
        arrow               =   [features(n,1),features(n,2),...
            cos(features(n,3)),sin(features(n,3))];
        scatter(features(n,1),features(n,2),'r*');
        text(features(n,1),features(n,2)+1,...
            strcat(num2str(labels(n))),'color',[0 0 0]);
        quiver(arrow(1),arrow(2),arrow(3),arrow(4),100,'color',[0 0 1]);
    end
    hold off
    xlim([-150,size(registered,2)]);
    
    subplot(132); imagesc(IRPM{t})
    title('Instantaneous Inter-Relation Patterm Matrix');
    xlabel('Targets ID'), ylabel('Targets ID')
    
    subplot(133); imagesc(cIRPM{t})
    title('Cumulative Inter-Relation Patterm Matrix');
    xlabel('Targets ID'), ylabel('Targets ID')
    drawnow;
    
    
    %% Results analysis wrt the ground truth
    fprintf('FOUND:--'); % groups that I found;
    for i=1: size(cgroup{t},2)
        fprintf('%s| ',num2str(cgroup{t}{i}))
    end
    fprintf('\n');
    
    fprintf('GT:--') % real groups;
    % GT has been made in relative labels
    for i=1: size(GT{t},2)
       GT{t}{i} = features(GT{t}{i},4)'; % convert to absolute labels
    end   
    for i=1: size(GT{t},2)
        fprintf('%s| ',num2str(GT{t}{i}))
    end
    fprintf('\n');
    
    TP(t)=0; % TRUE POSITIVES;
    for i=1: size(GT{t},2)
        GTtmp           =   GT{t}{i};
        GTcard          =   length(GTtmp); % numerosity of the GT group under analysis;
        for j=1: size(cgroup{t},2)
            grouptmp        =   cgroup{t}{j};
            groupcard       =   length(grouptmp); % numerosity of the GT group under analysis;
            inters          =   intersect(GTtmp,grouptmp);
            interscard      =   length(inters);
            if groupcard==2 && GTcard == 2 
                if isempty(setxor(GTtmp,grouptmp))
                    TP(t)    =   TP(t)+1;
                    break
                end
            elseif ge(interscard/max(GTcard,groupcard),2/3)
                TP(t)    =   TP(t)+1;
                break
            end
        end
    end
    FN(t)        =   size(GT{t},2)-TP(t);
    FP(t)        =   size(cgroup{t},2)- TP(t);
    if (TP(t)+FP(t))~=0
        precision(t)       =   TP(t)./(TP(t)+FP(t));
    end
    if (TP(t)+FN(t))~=0
        recall(t)          =   TP(t)./(TP(t)+FN(t));
    end
    fprintf('True Positive Rate --> %i/%i\n',TP(t),size(GT{t},2)); fprintf('--------------\n')
    
%     close all;
end
close all;

fprintf('Precision --> %f\n',mean(precision)); 
fprintf('Recall --> %f\n',mean(recall)); 
fprintf('--------------\n')


    

  




    

 
 