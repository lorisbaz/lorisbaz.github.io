function [group,IRPM] = inst_IRPM(features,distTH,theta_deg,L,verbose)
% [group,IRPM] = inst_IRPM(features,distTH,theta_deg,L,verbose)
%
% Extract the instantaneous Inter-relation Pattern Matrix (IRPM) given 
% tracking results and pose estimation
%
%INPUT:
% features  :=  The first two coords are the floor positions of the people. 
%               The third is the head/body orientation, centered on the person, coordinated
%               with the xy axis, and expressed in radians.
%               The fourth is the ID label, different for subject;
% distTH    := distance parameter
% theta     := angle of view of humans
% L         := max distance between humans (has to be greater than distTH)
% verbose   := if ==1, plot figures;
%
%OUTPUT:
% group :=  contains groups ID using instantaneous IRPM;
% IRPM  :=  instantaneous IRPM;

% Loris Bazzani, 
% April 18, 2011



num_p       =   size(features,1); % number of people;


%% Create standard 2D frustum
theta_rad = (theta_deg/180*pi)/2;
SVF2D.centre    = [0;0];
SVF2D.theta     = theta_rad;
SVF2D.r1        = [L*cos(theta_rad);L*sin(theta_rad)];
SVF2D.r2        = [L*cos(theta_rad);-L*sin(theta_rad)];
% plot([SVF2D.centre(1) SVF2D.r1(1)], [SVF2D.centre(2) SVF2D.r1(2)])
% hold on
% plot([SVF2D.centre(1) SVF2D.r2(1)], [SVF2D.centre(2) SVF2D.r2(2)])
% hold off


%% Instatiate the standard 2D frustum for each pedestrian
custumSVF2D = struct([]);
if verbose
    h1          =   figure;
end
for k=1:num_p
    % rotation
    R = [cos(features(k,3)),-sin(features(k,3));sin(features(k,3)),cos(features(k,3))];
    custumSVF2D(k).r1 = R*SVF2D.r1;
    custumSVF2D(k).r2 = R*SVF2D.r2;
    
    % traslation
    custumSVF2D(k).centre = features(k,1:2)';
    custumSVF2D(k).r1   = custumSVF2D(k).r1+custumSVF2D(k).centre;
    custumSVF2D(k).r2   = custumSVF2D(k).r2+custumSVF2D(k).centre;    
    
    if verbose
        figure(h1)
        subplot(121)
        hold on
        pfeatures = features(k,:);
        plot([custumSVF2D(k).centre(1) custumSVF2D(k).r1(1)], [custumSVF2D(k).centre(2) custumSVF2D(k).r1(2)])
        plot([custumSVF2D(k).centre(1) custumSVF2D(k).r2(1)], [custumSVF2D(k).centre(2) custumSVF2D(k).r2(2)])
        arrow               =   [pfeatures(1),pfeatures(2),...
            cos(pfeatures(3)),sin(pfeatures(3))];
        scatter(pfeatures(1),pfeatures(2),'r*');
        text(pfeatures(1)+5,pfeatures(2),...
            strcat(num2str(pfeatures(4))),'color',[0 0 0]);
        quiver(arrow(1),arrow(2),arrow(3),arrow(4),100,'color',[0 0 1]);
        hold off
    end

end


%% Compute the interaction matrix
Mtt = zeros(num_p,num_p);
for k=1:num_p
    for h = k+1:num_p
        XY1 = [custumSVF2D(k).centre;custumSVF2D(k).r1];
        XY2 = [custumSVF2D(h).centre;custumSVF2D(h).r1];
        inter1 = lineSegmentIntersect(XY1',XY2');
        XY1 = [custumSVF2D(k).centre;custumSVF2D(k).r1];
        XY2 = [custumSVF2D(h).centre;custumSVF2D(h).r2];
        inter2 = lineSegmentIntersect(XY1',XY2');
        XY1 = [custumSVF2D(k).centre;custumSVF2D(k).r2];
        XY2 = [custumSVF2D(h).centre;custumSVF2D(h).r1];
        inter3 = lineSegmentIntersect(XY1',XY2');
        XY1 = [custumSVF2D(k).centre;custumSVF2D(k).r2];
        XY2 = [custumSVF2D(h).centre;custumSVF2D(h).r2];
        inter4 = lineSegmentIntersect(XY1',XY2');
        
%         if verbose
%             pfeatures = features(k,:);
%             plot([custumSVF2D(k).centre(1) custumSVF2D(k).r1(1)], [custumSVF2D(k).centre(2) custumSVF2D(k).r1(2)])
%             hold on
%             plot([custumSVF2D(k).centre(1) custumSVF2D(k).r2(1)], [custumSVF2D(k).centre(2) custumSVF2D(k).r2(2)])
%             arrow               =   [pfeatures(1),pfeatures(2),...
%                 cos(pfeatures(3)),sin(pfeatures(3))];
%             scatter(pfeatures(1),pfeatures(2),'ro');
%             text(pfeatures(1),pfeatures(2)+1,...
%                 strcat(num2str(k)),'color',[0 1 0]);
%             quiver(arrow(1),arrow(2),arrow(3),arrow(4),100,'color',[0 0 1]);
%             
%             pfeatures = features(h,:);
%             plot([custumSVF2D(h).centre(1) custumSVF2D(h).r1(1)], [custumSVF2D(h).centre(2) custumSVF2D(h).r1(2)])
%             plot([custumSVF2D(h).centre(1) custumSVF2D(h).r2(1)], [custumSVF2D(h).centre(2) custumSVF2D(h).r2(2)])
%             arrow               =   [pfeatures(1),pfeatures(2),...
%                 cos(pfeatures(3)),sin(pfeatures(3))];
%             scatter(pfeatures(1),pfeatures(2),'ro');
%             text(pfeatures(1),pfeatures(2)+1,...
%                 strcat(num2str(h)),'color',[0 1 0]);
%             quiver(arrow(1),arrow(2),arrow(3),arrow(4),100,'color',[0 0 1]);
%             hold off
%         end
      
        if any([inter1.intAdjacencyMatrix,inter2.intAdjacencyMatrix,... % at least one intersection between segments
                inter3.intAdjacencyMatrix,inter4.intAdjacencyMatrix]==1) && ...
           (norm(features(k,1:2) - features(h,1:2)) < distTH) && ... % chenking distance constrain
            pointInTriangle(features(h,1:2)',custumSVF2D(k).centre,custumSVF2D(k).r1,custumSVF2D(k).r2) && ...
            pointInTriangle(features(k,1:2)',custumSVF2D(h).centre,custumSVF2D(h).r1,custumSVF2D(h).r2)

            Mtt(k, h) = 1;
            
        end
        

    end
end
if verbose
    figure(h1), sh1 = subplot(122);
    imagesc(Mtt), title('Instantaneous Inter-Relation Patterm Matrix');
    xlabel('Targets ID')
    ylabel('Targets ID')
    set(sh1,'XTickLabel',features(:,4),'YTickLabel',features(:,4));
end

%% Find connected conponents on the graph
[C,D] = graphconncomp(sparse(Mtt),'weak',true);
gg = 1;
for i = 1:C
    list = find(D==i);
    if length(list)>1
        group{gg} = features(list,4)';
        groupls{gg} = list;
        gg = gg+1;
    end
end
% Compose Mtt with global labels
[ii,jj] = find(Mtt==1);
for n = 1:length(ii)
    IRPM(features(ii(n),4),features(jj(n),4)) = 1;
end
if gg == 1 % means no group found
   group = [];
   IRPM  = 0;
end

% plot
if verbose
    subplot(121),
    for gg = 1:length(group)
        hold on
        M = mean(features(groupls{gg},1:2));
        Rays = pdist([M;features(groupls{gg},1:2)]);
        Rays = max(Rays(1:length(groupls{gg})))+10;
        circle(M,Rays,1000,'r-');
        hold off
    end
    title('Detected Groups')
end