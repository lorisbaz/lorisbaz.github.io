function  [group,cIRPM]   = cum_IRPM(IRPM,num_subj,t,SHIFT,THRESH)
% [group,cIRPM]   = cum_IRPM(IRPM,num_subj,t,SHIFT,THRESH)
%
% Extracts the cumulative Inter-relation Pattern Matrix (IRPM) given 
% instantaneous IRPMs and detects groups
%
%INPUT:
% IRPM      := instantaneous IRPM (cell array);
% num_subj  := max number of subjects
% t         := current time
% SHIFT     := size do the time window
% THRESH    := threshold to detect interactions
%
%OUTPUT:
% group :=  contains groups ID using cumulative IRPM;
% cIRPM :=  cumulative IRPM;

% Loris Bazzani, 
% April 18, 2011



%% cumulative IRPM compute
cIRPM   =   zeros(num_subj,num_subj);
for tt = t-SHIFT:t
    if tt>0
        cIRPM = cIRPM+IRPM{tt};
    end
end


%% Find connected conponents on the graph 
flag = 0; % 
cIRPM_TH = cIRPM>THRESH; % thresholding!
if any(cIRPM_TH(:)~=0)
    [C,D] = graphconncomp(sparse(cIRPM_TH),'weak',true);
    gg = 1;
    for i = 1:C
        list = find(D==i);
        if length(list)>1
            group{gg} = list;
            gg = gg+1;
        end
    end
    flag = 1;
end
if ~flag || gg == 1 % means no group found
   group  = [];
   cIRPM  = 0;
end