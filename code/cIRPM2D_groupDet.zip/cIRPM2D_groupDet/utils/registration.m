function [mytform, registered] = registration(input_points,base_points,I)


base=zeros(1000,600);

%Computing the parameters for the desired transformation.
mytform = cp2tform(input_points, base_points, 'projective');

%Performing the transform, truncating the result to fit the base image
if nargin>=3
registered = imtransform(I,mytform,...
                          'FillValues', 255,...
                          'XData', [1 size(base,2)],...
                          'YData', [1 size(base,1)]);
else
    registered = base;
end

%Overlaying both input and base images                      
%figure; imshow(registered)